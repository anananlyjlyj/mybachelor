
class Turtle:
    DIRS = [(0, 1), (1, 0), (0, -1), (-1, 0)]
    DIR_SYMBOL = ">v<^"
    PENS = ["", "r", "g", "b", "o"]
    COLORS = {" ": "white", "": "grey", "r": "red", "g": "green", "b": "blue", "o": "black"}

    def __init__(self, width, height):
        self.board = [[" " for _ in range(width)] for _ in range(height)]
        self.pos = 0, 0
        self.dir = 0
        self.pen = ""
        self.count = 0
    
    def print(self):
        print("+" + len(self.board[0]) * "-" + "+")
        for row in self.board:
            print("|", end="")
            print("".join(row), end="")
            print("|")
        print("+" + len(self.board[0]) * "-" + "+")
    
    def _pixel(self, color, show_dir):
        d = Turtle.DIR_SYMBOL[self.dir] if show_dir else "&nbsp;"
        return "<div style='background: {}; color: {} '>{}</div>".format(color, Turtle.COLORS[self.pen], d)
    
    def header(self):

        return "<html><head><style>div {text-shadow: 0 0 1px #000;font-family: consolas; font-size: 160%; border: 1px solid black; display: inline-block; width: 30px; height: 30px;}</style></head><body>"
    
    def footer(self):
        return "</body></html>"
    
    def _html(self):
        yield "<h1>" + str(self.count) + "</h1>"
        for x, row in enumerate(self.board):
            for y, p in enumerate(row):
                yield self._pixel(Turtle.COLORS[p], self.pos == (x, y))
            yield "<br>"
        yield "<br>"
    
    def html(self):
        return "".join(self._html())

    def walk(self, steps):
        self.count += 1
        d = Turtle.DIRS[self.dir]
        for _ in range(steps):
            if self.pen:
                self.board[self.pos[0]][self.pos[1]] = self.pen
            self.pos = self.pos[0] + d[0], self.pos[1] + d[1]
    
    def turn(self, angle):
        self.count += 1
        self.dir = (self.dir + angle) % 4

    def tail(self, pen):
        self.count += 1
        self.pen = Turtle.PENS[pen]


if __name__ == "__main__":
    from sys import argv
    
    if len(argv) == 1:
        print("Usage: prog DIMENSIONS [PROG_IN [HTML_OUT]]")
        exit(1)
    dim = int(argv[1])
    prog = argv[2] if len(argv) > 2 else "prog.txt"
    out = argv[3] if len(argv) > 3 else "out.html"
    
    turtle = Turtle(dim, dim)
    
    
    with open(prog) as fin:
        with open(out, "w") as fout:
            fout.write(turtle.header())
            for number, line in enumerate(fin, 1):
                line = line.strip()
                if not line:
                    print("skipping empty line")
                    continue
                try:
                    op, arg, *_ = line.split()
                    op = int(op)
                    arg = int(arg)
                    
                    if op == 1:
                        turtle.walk(arg)
                    elif op == 2:
                        turtle.turn(arg // 90)
                    elif op == 3:
                        turtle.tail(arg)
                except (ValueError, IndexError) as e:
                    print(e, "in line", number)
                else:
                    turtle.print()
                    fout.write(turtle.html())
            fout.write(turtle.footer())
